import './classifications.less'
import { fetchDatasourcesDocumentsInfo, resetObjects as resetLists } from './classificationsSlice'
import { getObjectsAllListSorted } from './classificationSelectors'
import DocumentCard from './components/DatasourceDocumentCard'
import NoResultsAvailable from '../../components/NoResultsAvailable'
import Page from '../../components/Page/page'
import { RootState } from '../../rootReducer'
import {
  URL_DOCUMENTS_ALL,
  FILTER_TYPES,
  FILTER_RISK_KEY,
  FILTER_DATASOURCE_CATEGORY,
  STRUCTURED_DATASOURCES,
  DATA_SOURCE_TYPES,
  MIXED_DATASOURCES
} from '../../constants'
import { IDocument } from '../../interfaces'
import { addNotification, INotificationParams } from '../notification/notificationSlice'
import useUrlContext from '../../hooks/useUrlContext'
import { formatFiltersToApiUrlParams } from '../../utils/urlUtil'
import { getShowLoader } from '../../reducers/requestReducer'
import Filters from '../filters/filters'
import { FileType } from '../filters/filtersSlice'
import { Dimmer, Header, Loader } from 'semantic-ui-react'
import { FormattedMessage, useIntl } from 'react-intl'
import { connect } from 'react-redux'
import React, { useEffect } from 'react'

interface IProps {
  list?: IDocument[]
  showLoader: boolean
  fetchDatasourcesDocumentsInfo: () => void
  resetLists: () => void
  addNotification: (notification: INotificationParams) => void
  dataSourcesTypes: string[]
  fileTypes: FileType[]
}

const DocumentsListByDatasource = ({
  list = [],
  showLoader,
  fetchDatasourcesDocumentsInfo,
  resetLists
}: IProps) => {
  const context = useUrlContext({ pageName: URL_DOCUMENTS_ALL })
  const intl = useIntl()
  const { risky, category } = formatFiltersToApiUrlParams(context.filters)
  let filteredList = list

  if (risky) {
    const inRisk = risky === 'Yes'
    const noRisk = risky === 'No'
    if (inRisk) {
      filteredList = list.filter(({ riskyObjectsCount = 0 }) => riskyObjectsCount > 0)
    } else if (noRisk) {
      filteredList = list.filter(({ riskyObjectsCount = 0 }) => riskyObjectsCount === 0)
    }
  }

  if (category) {
    const isStructured = category === 'Structured'
    const isUnstructured = category === 'Unstructured'
    if (isStructured) {
      filteredList = filteredList.filter(({ datasourceType }) => {
        const type = datasourceType as DATA_SOURCE_TYPES
        return STRUCTURED_DATASOURCES.includes(type) || MIXED_DATASOURCES.includes(type)
      })
    } else if (isUnstructured) {
      filteredList = filteredList.filter(({ datasourceType }) => {
        const type = datasourceType as DATA_SOURCE_TYPES
        return !STRUCTURED_DATASOURCES.includes(type) && !MIXED_DATASOURCES.includes(type)
      })
    }
  }

  useEffect(() => {
    fetchDatasourcesDocumentsInfo()
    return () => resetLists()
  }, [fetchDatasourcesDocumentsInfo, resetLists])

  const totalObjects = filteredList.reduce((acc, { objectsCount = 0 }) => acc + objectsCount, 0)
  const totalDatasources = filteredList.length
  const cardsLegendText = intl.formatMessage(
    { id: 'objects.card.header.legend' },
    {
      totalDatasources: intl.formatNumber(totalDatasources, {
        notation: 'compact'
      }),
      totalObjects: intl.formatNumber(totalObjects, {
        notation: 'compact'
      })
    }
  )

  return (
    <Page
      className="list-files-page"
      header={<Header content={intl.formatMessage({ id: 'objects.title' })} />}
    >
      <Dimmer active={showLoader} inverted>
        <Loader size="big">
          <FormattedMessage id="loader.text.loading" />
        </Loader>
      </Dimmer>
      <div className="table_controls xs-mb-12">
        <Filters
          context={context}
          pageName={URL_DOCUMENTS_ALL}
          title={intl.formatMessage({ id: 'table.legend.objects' })}
          filters={[
            {
              title: 'filters.risk',
              key: FILTER_RISK_KEY,
              values: [
                intl.formatMessage({ id: 'filter.risk.yes' }),
                intl.formatMessage({ id: 'filter.risk.no' })
              ],
              type: FILTER_TYPES.toggle
            },
            {
              title: 'filters.category',
              key: FILTER_DATASOURCE_CATEGORY,
              values: [
                intl.formatMessage({ id: 'dataSources.structured.tab.structured' }),
                intl.formatMessage({ id: 'dataSources.structured.tab.unstructured' })
              ],
              type: FILTER_TYPES.discreet
            }
          ]}
        />
      </div>
      {totalDatasources ? (
        <>
          <div className="cards-list-header xs-mb-12">{cardsLegendText}</div>
          <div className="list-cards-info">
            {filteredList.map((info, ind) => (
              <DocumentCard data={info} key={ind} />
            ))}
          </div>
        </>
      ) : (
        <>{!showLoader && <NoResultsAvailable />}</>
      )}
    </Page>
  )
}

const mapStateToProps = (state: RootState) => ({
  list: getObjectsAllListSorted(state),
  showLoader: getShowLoader(),
  dataSourcesTypes: state.filters.dataSourcesTypes,
  fileTypes: state.filters.fileTypes
})

const mapDispatchToProps = {
  fetchDatasourcesDocumentsInfo,
  addNotification,
  resetLists
}

export default connect(mapStateToProps, mapDispatchToProps)(DocumentsListByDatasource)
