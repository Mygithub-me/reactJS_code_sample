import './filters.less'
import ToggleFilter from './components/toggleFilter'
import FilterDiscreet from './components/filterDiscreet'
import SelectedFiltersControl from './components/selectedFiltersControl'
import { managePageFilters, removeAllPageFilters, UrlContextParams } from '../../utils/urlUtil'
import {
  SORT_BY,
  FILTER_TYPES,
  END_DATE,
  IS_ALL,
  IS_AT_RISK,
  IS_DRAFT,
  IS_RESOLVED,
  IS_SENSITIVE,
  IS_UNRESOLVED,
  PAGE,
  SORT_DIRECTION,
  START_DATE,
  PAGE_VIEW_KEY
} from '../../constants'
import React, { SyntheticEvent, useState } from 'react'
import { Button, Dropdown, Popup } from 'semantic-ui-react'
import { Funnel as IconFunnel } from 'phosphor-react'
import { FormattedMessage, useIntl } from 'react-intl'

export type FilterName = { key: string; name: string }

export interface FilterItemProps {
  title: string
  key: string
  values: string[]
  names?: FilterName[]
  type?: string
}
export interface FilterIProps {
  context: UrlContextParams
  pageName: string
  title?: string
  filters: FilterItemProps[]
  sort?: { value?: string; text: string; selected?: boolean }[]
  changeFunction?: (key: string, setValue?: string) => void
}
const TabFilters = [
  PAGE,
  SORT_DIRECTION,
  SORT_BY,
  START_DATE,
  END_DATE,
  `${IS_SENSITIVE}_${PAGE}`,
  `${IS_AT_RISK}_${PAGE}`
]
const PageFilters = [
  IS_ALL,
  IS_AT_RISK,
  IS_SENSITIVE,
  IS_DRAFT,
  IS_RESOLVED,
  IS_UNRESOLVED,
  PAGE_VIEW_KEY
]

const FiltersComponent = (props: FilterIProps): React.ReactElement => {
  const { filters, context, pageName: filterPage, changeFunction, sort = [] } = props
  const intl = useIntl()
  const [isFiltersOpened, setIsFiltersOpened] = useState(false)

  let allFilterNames: FilterName[] = []
  filters.forEach((filter) => {
    if (filter.names) {
      allFilterNames = [...allFilterNames, ...filter.names]
    }
  })

  const handleClose = () => setIsFiltersOpened(false)
  const handleOpen = () => setIsFiltersOpened(true)
  const handleClearFilters = () => removeAllPageFilters(filterPage)
  const filtersToControl = Object.entries(context.filters)
    .filter(([key]) => ![...TabFilters, ...PageFilters].includes(key))
    .map(([key, value]) => {
      return Array.isArray(value) ? value.map((val) => ({ key, value: val })) : { key, value }
    })
    .flat()
  const setSort = (_: SyntheticEvent, data) => {
    setSelectedSortValue(data.value)
    managePageFilters({
      pageName: filterPage,
      filterKey: SORT_BY,
      filterValues: [data.value],
      action: data.value ? 'add' : 'remove'
    })
  }

  const [selectedSortValue, setSelectedSortValue] = useState(context.pageSort)
  return (
    <>
      {sort.length ? (
        <div className="sort-container">
          <div className="sort-label">
            <label htmlFor="sort">
              <FormattedMessage id="label.text.sort" />
            </label>
          </div>
          <div className="xs-mr-12 xs-ml-12 sort-select">
            <Dropdown
              placeholder={intl.formatMessage({
                id: 'sort.dropdown.placeholder'
              })}
              clearable
              selection
              defaultValue={selectedSortValue}
              options={sort}
              onChange={setSort}
            />
          </div>
        </div>
      ) : (
        ''
      )}
      <div className="filters-wrapper">
        <Popup
          className="filters-popup"
          on="click"
          open={isFiltersOpened}
          position="bottom center"
          onClose={handleClose}
          onOpen={handleOpen}
          trigger={
            <div className="filters-control">
              <Button
                active={isFiltersOpened}
                className={`filter-trigger`}
                content={
                  <IconFunnel
                    color={isFiltersOpened ? 'var(--color-white)' : '#959DA5'}
                    size={20}
                    weight="fill"
                  />
                }
                type="button"
              />
              {Object.keys(filtersToControl).length === 0 && (
                <Button
                  active={isFiltersOpened}
                  className={`filter-trigger name`}
                  content={intl.formatMessage({ id: 'text.filter' })}
                  type="button"
                />
              )}
            </div>
          }
          content={
            <div className="filters-container custom-scrollbar">
              {filters.map((filter, index) => {
                const filterType = filter.type || FILTER_TYPES.discreet
                if (filterType === FILTER_TYPES.toggle) {
                  return (
                    <ToggleFilter
                      key={index}
                      filterPage={filterPage}
                      filters={context.filters}
                      filterOptions={filter.values}
                      filterKey={filter.key}
                      filterTitleI18NId={filter.title}
                      changeFunction={changeFunction}
                    />
                  )
                } else {
                  return (
                    <FilterDiscreet
                      key={index}
                      filterPage={filterPage}
                      filters={context.filters}
                      filterOptions={filter.values}
                      filterKey={filter.key}
                      filterNames={filter.names}
                      filterTitleI18NId={filter.title}
                      changeFunction={changeFunction}
                    />
                  )
                }
              })}
            </div>
          }
        />
        {filtersToControl.length > 0 && (
          <>
            <SelectedFiltersControl
              filters={filtersToControl}
              filterNames={allFilterNames}
              pageName={filterPage}
            />
            <Button
              className="clear-filters"
              content={<FormattedMessage id="filters.button.clearAll" />}
              onClick={handleClearFilters}
            />
          </>
        )}
      </div>
    </>
  )
}

export default FiltersComponent
