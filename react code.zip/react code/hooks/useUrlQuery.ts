import { useLocation } from 'react-router-dom'

const useUrlQuery = (): any => {
  const urlParams: any = new URLSearchParams(useLocation().search)
  return Object.fromEntries(urlParams)
}

export default useUrlQuery
