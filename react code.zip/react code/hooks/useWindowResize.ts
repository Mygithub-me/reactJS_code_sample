import { useLayoutEffect, useState } from 'react'

export type WindowDimensions = {
  width: number
  height: number
}

const useWindowSize = (): WindowDimensions => {
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  useLayoutEffect(() => {
    function updateSize() {
      setDimensions({ width: window.innerWidth, height: window.innerHeight })
    }
    window.addEventListener('resize', updateSize)
    updateSize()
    return () => window.removeEventListener('resize', updateSize)
  }, [])

  return dimensions
}

export default useWindowSize
