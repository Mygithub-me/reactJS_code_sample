import './table.less'
import RegularColumn from './regularColumn'
import { SORT_ORDER } from '../../interfaces'
import { getMaskedString } from '../../utils/stringUtil'
import React, { useState } from 'react'
import { Checkbox, Table, TableBodyProps } from 'semantic-ui-react'

const calculateColumnWidths = (columns: TableColumn[]): number[] => {
  const usedPercentage = columns.reduce((acc, current) => (acc += current.widthPercent || 0), 0)
  const columnsWithoutWidth = columns.filter((c) => !c.widthPercent)
  return columns.map(({ widthPercent = 0 }) => {
    return widthPercent || Math.round((100 - usedPercentage) / columnsWithoutWidth.length)
  })
}

type classes = {
  table?: string
  thead?: string
  th?: string
  tr?: string
  td?: string
}

type TableProps = {
  classes?: classes
  sortable?: boolean
  selectable?: boolean
  unstackable?: boolean
}

type RowProps = {
  dataKey?: string | number
  onClick?: (data: any) => void
}

type TableBaseColumn = {
  title: string
  dataKey: string
  onClick?: () => void
  sorted?: SORT_ORDER | null
  className?: string
  isColumnSelectable?: boolean
  isColumnSelected?: boolean
  widthPercent?: number
  onColumnSelectChange?: () => void
}

interface TableColumnWithCellRenderer extends TableBaseColumn {
  cellRenderer?: (item: any) => React.ReactElement | string | number
  masking?: never
  maskingToggleDisabled?: never
}
interface TableColumnWithMasking extends TableBaseColumn {
  masking?: boolean
  cellRenderer?: never
  maskingToggleDisabled?: boolean
}
/**A column config can only contain either masking or cellRenderer as making cannot be provided in case of a complex component */
export type TableColumn = TableColumnWithCellRenderer | TableColumnWithMasking
export interface IDataExpandable {
  isExpanded: boolean
  cellRenderer: () => React.ReactElement | string | number | boolean
}

interface IProps {
  columns: TableColumn[]
  data: TableBodyProps
  dataExpandable?: IDataExpandable[]
  tableProps?: TableProps
  rowProps?: RowProps
  hideTableHeader?: boolean
  isCellRenderer?: boolean // TODO: remove this prop after adding "cellRenderer" function to every table
}

const GenericTable = (props: IProps): React.ReactElement => {
  const {
    columns,
    data,
    dataExpandable = [],
    tableProps,
    rowProps,
    isCellRenderer,
    hideTableHeader
  } = props
  let classes

  if (tableProps) {
    classes = tableProps.classes
  }
  const maskingDefaultConfig = columns
    .filter((col) => col.masking)
    .reduce((acc, col) => {
      acc[col.dataKey] = true
      return acc
    }, {})
  const [maskingToggle, setMaskingToggle] = useState<{ [key: string]: boolean }>(
    maskingDefaultConfig
  )

  const columnWidths = calculateColumnWidths(columns)
  const columnsByKeyMap = {}
  columns.forEach((col) => (columnsByKeyMap[col.dataKey] = col))
  const headers = (
    <Table.Row>
      {columns.map((col, ind) => {
        const {
          title,
          className = '',
          isColumnSelectable,
          onColumnSelectChange,
          isColumnSelected,
          onClick,
          masking = false,
          maskingToggleDisabled = false
        } = col
        const combinedClass = `${classes?.th} ${className}`

        const getHeaderContent = () => {
          if (masking) {
            return (
              <span className="field-selectable">
                <span onClick={onClick || undefined}>{col.title}</span>
                {!maskingToggleDisabled && (
                  <Checkbox
                    title={title}
                    toggle
                    checked={maskingToggle[col.dataKey]}
                    onChange={(e) => {
                      e.stopPropagation()
                      setMaskingToggle({
                        ...maskingToggle,
                        [col.dataKey]: maskingToggle ? !maskingToggle[col.dataKey] : true
                      })
                    }}
                    label=""
                    className="simple fitted xs-ml-8"
                  />
                )}
              </span>
            )
          }
          if (isColumnSelectable) {
            return (
              <span className="field-selectable">
                <Checkbox
                  title={title}
                  checked={isColumnSelected}
                  onChange={onColumnSelectChange}
                  label=""
                />
                <span onClick={onClick || undefined}>{col.title}</span>
              </span>
            )
          }
          return col.title
        }
        return (
          <Table.HeaderCell
            key={`${title}-${ind}`}
            className={combinedClass}
            style={{ width: columnWidths[ind] + '%' }}
            onClick={onClick}
            title={col.title}
          >
            {getHeaderContent()}
          </Table.HeaderCell>
        )
      })}
    </Table.Row>
  )

  const rows = data.map((item, i) => {
    const handleClick = () => {
      return rowProps?.onClick && rowProps.dataKey && rowProps.onClick(item[rowProps.dataKey])
    }
    const cells = Object.keys(columnsByKeyMap)

    return (
      <React.Fragment key={i}>
        <Table.Row
          onClick={handleClick}
          {...(classes && classes.tr ? { className: classes.tr } : {})}
        >
          {cells.map((key, p) => (
            <Table.Cell className={classes?.td} key={p} {...(p == 0 ? { width: 2 } : {})}>
              {isCellRenderer && columnsByKeyMap[key].cellRenderer ? (
                columnsByKeyMap[key].cellRenderer(item)
              ) : columnsByKeyMap[key].masking ? (
                <RegularColumn
                  title={columnsByKeyMap[key].title}
                  content={
                    maskingToggle && maskingToggle[key] ? getMaskedString(item[key]) : item[key]
                  }
                />
              ) : (
                item[key]
              )}
            </Table.Cell>
          ))}
        </Table.Row>
        {dataExpandable.length > 0 && dataExpandable[i]?.isExpanded && (
          <Table.Row colSpan={cells.length}>
            <Table.Cell colSpan={cells.length}>{dataExpandable[i].cellRenderer()}</Table.Cell>
          </Table.Row>
        )}
      </React.Fragment>
    )
  })

  return (
    <Table
      basic="very"
      {...(tableProps && tableProps.sortable ? { sortable: true } : {})}
      {...(tableProps && tableProps.sortable ? { sortable: true } : {})}
      {...(tableProps && tableProps.selectable ? { selectable: true } : {})}
      {...(tableProps && tableProps.unstackable ? { unstackable: true } : {})}
      {...(classes && classes.table ? { className: classes.table } : {})}
    >
      <Table.Header
        {...(classes && classes.thead ? { className: classes.thead } : {})}
        className={hideTableHeader ? 'header-hidden' : ''}
      >
        {headers}
      </Table.Header>
      <Table.Body>{rows}</Table.Body>
    </Table>
  )
}

export default GenericTable
