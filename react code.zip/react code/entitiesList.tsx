import './entities.less'
import {
  ACTION_ENTITIES_LIST_FETCH,
  ACTION_ENTITIES_LIST_FETCH_QUERY,
  Entity,
  fetchEntities,
  fetchEntitiesByQuery,
  setSort
} from './entitiesSlice'
import TableListAll from './components/tableList'
import { getEntitiesAllListSorted } from './entitiesSelectors'
import { RootState } from '../../rootReducer'
import { SortParams } from '../../utils/sortUtil'
import {
  LIMIT_DEFAULT,
  IS_ALL,
  PAGE,
  URL_ENTITIES,
  FILTER_RISK_KEY,
  FILTER_TYPES,
  IS_AT_RISK,
  FILTER_RESIDENCY_KEY,
  API_FILTER_RESIDENCIES_KEY,
  FILTER_PARTNER_ID_KEY,
  API_FILTER_DATA_SOURCES,
  DATA_SOURCE_TYPES
} from '../../constants'
import { getShowLoader } from '../../reducers/requestReducer'
import { FilterParams, IGetEntitiesParams, IResidency } from '../../interfaces'
import useUrlContext from '../../hooks/useUrlContext'
import TableLegend from '../../components/TableLegend'
import NoResultsAvailable from '../../components/NoResultsAvailable'
import useDebounce from '../../hooks/useDebounce'
import LoaderView from '../../components/Loader/loader'
import PaginationView from '../../components/Pagination/pagination'
import Filters from '../filters/filters'
import { formatFiltersToApiUrlParams, updateUrlPageFilters } from '../../utils/urlUtil'
import { getResidenciesAllListSorted } from '../residencies/residenciesSelectors'
import { connect } from 'react-redux'
import React, { SyntheticEvent, useEffect, useRef, useState } from 'react'
import { useIntl } from 'react-intl'
import { Search, SearchProps } from 'semantic-ui-react'

interface IProps {
  list?: Entity[]
  total?: number
  queryTotal?: number
  baseUrl?: string
  sort: SortParams
  showLoader: boolean
  widgetView?: boolean
  fetchEntities: (filters: IGetEntitiesParams) => void
  fetchEntitiesByQuery: (filters: IGetEntitiesParams) => void
  setSort: (payload: { column: string; list: string }) => void
  residencyList: IResidency[] | undefined
  isPartner?: boolean
  isJira?: boolean
  partnerIds?: string[]
}

const EntitiesList = (props: IProps) => {
  const {
    list = [],
    total = 0,
    sort,
    baseUrl,
    showLoader,
    widgetView,
    fetchEntities,
    setSort,
    residencyList,
    isPartner = false,
    isJira = false,
    partnerIds,
    queryTotal,
    fetchEntitiesByQuery
  } = props
  const intl = useIntl()
  const context = useUrlContext({ pageName: URL_ENTITIES })
  const datasourceId = context.contextFilters.datasourceId || ''
  const datasourceType = context.queryParams.datasourceType as DATA_SOURCE_TYPES
  const bucketId = context.contextFilters.bucketId
  const isAws = datasourceType === DATA_SOURCE_TYPES.aws
  const page = context.pageFilters[IS_ALL][PAGE]
  const listKey = 'all'

  const contextFilters = useRef(context.contextFilters).current
  const { risky, [FILTER_RESIDENCY_KEY]: residencyFilter } = formatFiltersToApiUrlParams(
    context.filters
  )

  const handleSetSort = (column: string) => setSort({ column, list: listKey })
  const listTotal = isPartner ? queryTotal || 0 : total
  const totalPages = Math.ceil(listTotal / LIMIT_DEFAULT)
  const tableList = widgetView ? list.slice(0, 10) : list
  const [search, setSearch] = useState('')
  const handleSearchChange = (_: SyntheticEvent, { value = '' }: SearchProps) => {
    setSearch(value)
  }

  const debouncedSearch = useDebounce(search, 300)
  const handleChangeFilter = () => {
    page > 1 &&
      updateUrlPageFilters({
        pageName: URL_ENTITIES,
        pageFilters: { [PAGE]: 1 }
      })
  }
  useEffect(() => {
    if (isPartner || isJira || isAws) {
      const filters: FilterParams = { filter: [], booleanFilter: [] }
      if (filters.filter) {
        partnerIds &&
          filters.filter.push({
            key: FILTER_PARTNER_ID_KEY,
            values: partnerIds
          })
        debouncedSearch &&
          filters.filter.push({
            key: 'NAME',
            values: [debouncedSearch]
          })
        bucketId &&
          filters.filter.push({
            key: 'BUCKET_NAMES',
            values: [bucketId]
          })
      }
      if (filters.booleanFilter) {
        risky &&
          filters.booleanFilter.push({
            key: API_FILTER_DATA_SOURCES.isRisky,
            value: risky === 'Yes' ? true : false
          })
      }

      fetchEntitiesByQuery({ page, datasourceId, filters, isJira, isAws })
    } else {
      const filterObj = {
        ...contextFilters,
        [PAGE]: page,
        searchQuery: debouncedSearch
      }
      if (risky !== undefined) {
        filterObj[IS_AT_RISK] = risky === 'Yes'
      }
      if (residencyFilter !== undefined) {
        filterObj[API_FILTER_RESIDENCIES_KEY] = residencyFilter.split(',')
      }
      fetchEntities(filterObj)
    }
  }, [
    debouncedSearch,
    contextFilters,
    isJira,
    page,
    datasourceId,
    fetchEntities,
    risky,
    residencyFilter
  ])
  const filters = isPartner
    ? [
        {
          title: 'filters.risk',
          key: FILTER_RISK_KEY,
          values: [
            intl.formatMessage({ id: 'filter.risk.yes' }),
            intl.formatMessage({ id: 'filter.risk.no' })
          ],
          type: FILTER_TYPES.toggle
        }
      ]
    : [
        {
          title: 'filters.risk',
          key: FILTER_RISK_KEY,
          values: [
            intl.formatMessage({ id: 'filter.risk.yes' }),
            intl.formatMessage({ id: 'filter.risk.no' })
          ],
          type: FILTER_TYPES.toggle
        },
        {
          title: 'filters.residency',
          key: FILTER_RESIDENCY_KEY,
          values: residencyList?.map((item) => item.name) || [],
          type: FILTER_TYPES.discreet
        }
      ]

  return (
    <div className="content-wrapper">
      <div className="table_controls xs-mb-12">
        <div className="list-search">
          <Search
            onSearchChange={handleSearchChange}
            value={search}
            input={{
              icon: 'search',
              iconPosition: 'left',
              placeholder: intl.formatMessage({
                id: 'list.search.placeholder'
              })
            }}
            open={false}
          />
        </div>
        <Filters
          context={context}
          pageName={URL_ENTITIES}
          title={intl.formatMessage({ id: 'table.legend.objects' })}
          filters={filters}
          changeFunction={handleChangeFilter}
        />
      </div>
      <TableLegend
        total={listTotal}
        showing={tableList.length}
        page={page}
        name={intl.formatMessage({ id: 'table.legend.entities' })}
      />

      {tableList.length > 0 && (
        <TableListAll
          list={tableList}
          sort={sort}
          setSort={handleSetSort}
          context={context}
          baseUrl={baseUrl}
          isPartner={isPartner}
          isJira={isJira}
          isAws={isAws}
        />
      )}
      {totalPages > 1 && !widgetView && (
        <div className="xs-mt-16">
          <PaginationView
            pageName={URL_ENTITIES}
            currentPage={page}
            totalPages={totalPages}
            activeTab={IS_ALL}
          />
        </div>
      )}
      <LoaderView showLoader={showLoader} />
      {!showLoader && tableList.length === 0 && <NoResultsAvailable />}
    </div>
  )
}

const mapStateToProps = (state: RootState) => ({
  list: getEntitiesAllListSorted(state),
  total: state.entities.all.total,
  sort: state.entities.all.sort,
  showLoader:
    getShowLoader(ACTION_ENTITIES_LIST_FETCH) || getShowLoader(ACTION_ENTITIES_LIST_FETCH_QUERY),
  residencyList: getResidenciesAllListSorted(state)
})

const mapDispatchToProps = { fetchEntities, setSort, fetchEntitiesByQuery }

export default connect(mapStateToProps, mapDispatchToProps)(EntitiesList)
